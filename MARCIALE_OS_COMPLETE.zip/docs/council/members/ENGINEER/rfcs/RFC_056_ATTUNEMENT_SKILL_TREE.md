# Engineering RFC / Design Spec: Attunement Skill Tree & Branching Talents

> **Author:** `@engineer` (Max — Seat E, Chief Construction Lead)
> **Executor:** `@forge` (Agent 3 - Autonomous Coder)
> **Target Repository:** `Marciale-OS` (`Gamecompanion/files`)
> **Build:** 56 / Aetherweave Build 28
> **Status:** Draft — Pending Supreme Commander Ratification
> **SPI (per roadmap methodology):** 88 / 100 (Strategic 22, Practicality 23, Independence 25, Risk 2)

---

## 1. Context & Architectural Goal

* **Objective:** Introduce a data-driven **Attunement Skill Tree** that lets players spend
  Attunement Points (earned on hero level-up) to unlock and upgrade **branching passive &
  active talents** across the seven magic schools (Water, Earth, Fire, Wind, Healing,
  Barrier, Demon/Dark), granting permanent stat and skill modifiers.
* **Target Path(s):** `Gamecompanion/files/src/data/`, `Gamecompanion/files/src/systems/`, `Gamecompanion/files/src/main.js`, `Gamecompanion/files/index.html`, `Gamecompanion/files/tests/`
* **Tech Stack & Libraries:** Node.js 20+ (ES Modules, Vite build), JavaScript (existing
  codebase convention — **not** TypeScript/Zod), `node --test` unit runner.
* **Architectural Bounds:**
  * Do **NOT** introduce new third-party npm dependencies.
  * Respect the **80% Blast-Radius Ceiling** — surgical additive diffs only to `main.js` and existing systems.
  * Keep business logic pure in the new `AttunementSystem`; side-effects (state writes, event emits) isolated.

---

## 2. Input/Output Data Contracts (Schemas First)

The codebase is data-driven JS, so schemas are defined as object contracts.

```js
// attunementTree data contract (src/data/attunementTree.js)
export const attunementTree = {
  maxPointsPerBranch: 5,                 // branch mastery cap
  branches: [
    {
      id: 'water',                        // magic school id
      school: 'water',
      name: 'Tidal Weave',
      color: '#4a9af0',
      nodes: [
        { id: 'water-1', name: 'Hydro Focus', type: 'passive', maxRank: 3,
          effect: { stat: 'magicDamage', perRank: 0.03 },
          cost: [1, 1, 2], requirements: { heroLevel: 2 } },
        { id: 'water-2', name: 'Riptide', type: 'active', maxRank: 2,
          effect: { skill: 'water_ball', multiplier: 0.5 },
          cost: [1, 2], requirements: { heroLevel: 5, parents: ['water-1'] } }
      ]
    }
  ]
};

// AttunementSystem state contract (player.attunement)
{
  points: 0,                              // unspent attunement points
  totalSpent: 0,
  ranks: { 'water-1': 1, 'water-2': 0 }   // nodeId -> current rank (0 = locked)
}
```

---

## 3. Business Logic & Mathematical Rules

* **Point Earning:** On `WEAVER_LEVEL_UP`, award `1 + floor(newLevel / 5)` attunement
  points (level 1 → +1, level 5 → +2, level 10 → +3 ...). Emit `ATTUNEMENT_POINT_EARNED`.
* **Node Unlock/Upgrade:** `spendPoint(nodeId)`:
  * Validates: node exists, current rank `< maxRank`, unspent `points > 0`,
    `currentRank + 1 ≤ cost[currentRank]` budget, and all `requirements` met
    (heroLevel, and each `parent` node ranked ≥ 1).
  * On success: increment rank, deduct cost, accumulate stat/skill effect, persist state,
    emit `ATTUNEMENT_NODE_RANKED { nodeId, rank, branch }`.
* **Stat Aggregation:** `getModifiers()` returns the merged active modifiers from all ranked
  nodes (stat deltas + skill multipliers), consumed by `StatEngine`/combat.
* **Branch Mastery:** when a branch's total ranks reach `maxPointsPerBranch`, grant a
  branch capstone passive and emit `ATTUNEMENT_BRANCH_MASTERED { branchId }`.
* **Guard Rules:**
  * **Rule A:** Cannot spend a point if any `parent` node is rank 0.
  * **Rule B:** Cannot exceed a node's `maxRank` or a hero's total points.
  * **Rule C:** Requirement `heroLevel` is checked against current hero level only.

---

## 4. Defensive Coding & Edge Cases

| Edge Case / Condition | Expected System Behavior |
|---|---|
| Unknown `nodeId` | Return `{ spent:false, reason:'unknown-node' }`; no state mutation |
| Insufficient points | Return `{ spent:false, reason:'no-points' }` |
| Node at `maxRank` | Return `{ spent:false, reason:'max-rank' }` |
| Parent not ranked | Return `{ spent:false, reason:'requirement-unmet' }` |
| Hero level below requirement | Return `{ spent:false, reason:'hero-level' }` |
| Duplicate `WEAVER_LEVEL_UP` / repeated grant | Guard by tracking `pointsAwardedAtLevel` to avoid double-counting |
| Missing state path (`player.attunement`) | Initialize with zeroed ranks + 0 points |

---

## 5. File Structure & Delivery Blueprint

```text
Gamecompanion/files/src/
├── data/attunementTree.js        # NEW — data-driven branches & talent nodes
├── systems/AttunementSystem.js   # NEW — point economy, spend/rank logic, modifier aggregation
├── core/EventBus.js              # MODIFY — add 3 events
├── main.js                       # MODIFY (surgical) — instantiate, wire events, UI modal, reportSnapshot
├── index.html                    # MODIFY — add "Attune" button
└── tests/AttunementSystem.test.js  # NEW — unit suite
```

---

## 6. Acceptance Criteria & Test Verification

* [ ] **TC1 (Point grant):** Hero level-up awards `1 + floor(level/5)` points and emits `ATTUNEMENT_POINT_EARNED`.
* [ ] **TC2 (Happy Path spend):** Spending a point on an unlocked node increments rank, deducts points, persists state.
* [ ] **TC3 (Guard: unknown node):** Returns `'unknown-node'`, no mutation.
* [ ] **TC4 (Guard: parent required):** Child node locked until parent ranked ≥ 1.
* [ ] **TC5 (Guard: max rank):** Cannot exceed node `maxRank`.
* [ ] **TC6 (Modifier aggregation):** Ranked nodes produce correct merged stat/skill modifiers.
* [ ] **TC7 (Branch mastery):** Branch capstone fires at `maxPointsPerBranch`.
* [ ] **Gate:** `npm --prefix "Gamecompanion/files" test` passes all existing (53) + new tests; `npm run build` clean; pangolin SEV-0 Nominal.

---

## Direct Execution Directive for `@forge`
**Instructions for `@forge`:**
Read this RFC completely. Implement the file structure in Section 5 following the existing
ES-Module/JS conventions (`node --test`, data-driven objects, event bus wiring). Keep diffs
surgical and within the 80% blast-radius ceiling. Write a complete unit test suite in
`tests/AttunementSystem.test.js` covering all criteria in Section 6. Run the test runner and
`npm run build`, then output both the code diff and test-pass logs for `@pangolin` independent
verification and `@engineer` Layer-4 acceptance.

---
*Submitted for ratification by*  
**ENGINEER (Max) — Seat E, JARWEN High Council**
